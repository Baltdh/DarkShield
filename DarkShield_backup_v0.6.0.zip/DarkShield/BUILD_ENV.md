# DarkShield — ambiente de compilação

## Requisitos
- JDK 21
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Gradle 8.11.1

## Linux
Instale o Android Command-line Tools no SDK e execute:

```bash
export ANDROID_HOME="$HOME/Android/Sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
./tools/prepare_build_env.sh
gradle --no-daemon clean assembleDebug
```

O APK será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Docker
O `Dockerfile` cria um ambiente isolado com JDK/Gradle/SDK e compila o APK:

```bash
docker build -t darkshield-build .
docker run --rm -v "$PWD:/workspace" darkshield-build
```

## GitHub Actions
O workflow `.github/workflows/android-apk.yml` compila automaticamente o APK de debug e publica o APK como artefato quando executado manualmente ou após push na branch `main`.

## Limite desta entrega
O ambiente desta sessão não tem rede no container nem SDK Android instalado; portanto o Dockerfile/workflow são preparados para execução em uma máquina/runner com acesso aos repositórios oficiais. A ausência de compilação local nesta sessão não deve ser interpretada como um APK já validado.
