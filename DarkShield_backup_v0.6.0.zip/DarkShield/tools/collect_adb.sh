#!/usr/bin/env bash
set -euo pipefail
OUT="darkshield_adb_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUT"
echo "Verificando dispositivo..."
adb devices
adb shell getprop > "$OUT/getprop.txt"
adb shell settings list global > "$OUT/settings_global.txt"
adb shell settings list secure > "$OUT/settings_secure.txt"
adb shell pm list packages -f > "$OUT/packages.txt"
adb shell dumpsys package > "$OUT/dumpsys_package.txt"
adb shell dumpsys device_policy > "$OUT/device_policy.txt"
adb shell dumpsys accessibility > "$OUT/accessibility.txt"
adb shell dumpsys notification > "$OUT/notification.txt"
echo "Coleta concluída: $OUT"
