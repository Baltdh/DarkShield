# Modelo de segurança do DarkShield

O DarkShield é uma ferramenta de auditoria local. Ele procura indicadores de risco observáveis pelas APIs normais do Android.

Ele **não** declara que um telefone foi invadido apenas porque encontra:
- ADB ou modo desenvolvedor ativos;
- um serviço de acessibilidade;
- um app instalado fora da loja;
- permissões sensíveis;
- software legítimo de suporte remoto.

Esses sinais precisam ser interpretados em conjunto. Sem root, o aplicativo não consegue inspecionar integralmente processos, partições protegidas, memória do kernel ou todos os mecanismos de persistência.

A versão atual também não envia dados para a internet e não contém permissão de rede no manifesto.
