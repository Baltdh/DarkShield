# Changelog

## 0.6.0
- Build metadata aligned to version 0.6.0 / versionCode 6.
- Added reproducible build documentation.
- Added Docker-based build environment definition.
- Added GitHub Actions APK build workflow.
- Added SDK preparation and build scripts.
- Hardened app manifest: cleartext traffic disabled and Android app backup disabled.
- Security model documented so findings are not presented as proof of compromise.
