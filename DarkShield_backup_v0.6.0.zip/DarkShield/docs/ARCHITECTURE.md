# Arquitetura — DarkShield 0.2.0

## Camadas
`MainActivity` apresenta o estado do scan e o relatório.

`SecurityScanner` coleta apenas dados disponíveis por APIs públicas do Android e atribui pontos às evidências.

`ScanFinding` representa um achado com severidade, evidência, pacote, pontuação e ação sugerida.

## Modelo de risco
A pontuação é deliberadamente heurística. Indicadores independentes somam pontos e o app exibe o total normalizado para 0–100. Não existe classificação "infectado" baseada em um único nome, permissão ou serviço.

## Regras importantes
- Acessibilidade de sistema não é tratada automaticamente como malware.
- Acessibilidade de terceiros ativa recebe atenção maior porque pode interagir com a interface e, dependendo da configuração, consultar conteúdo da janela.
- Administradores do dispositivo legítimos podem existir; sistema e apps de gestão conhecidos recebem tratamento diferente.
- Marcadores de acesso remoto só aumentam o risco de forma relevante quando corroborados por outros indicadores.
- ADB ativo é um ponto de atenção, não prova de comprometimento.
- O app não desinstala, bloqueia, apaga ou altera outros aplicativos automaticamente.

## Privacidade
A análise é local. Não há backend, conta, telemetria ou upload de APKs nesta versão.

## Limites
O scanner não acessa a memória de outros processos, partições protegidas nem componentes privilegiados do sistema. Para auditoria profunda, deve ser usado um fluxo ADB/root separado e explicitamente autorizado pelo usuário.
